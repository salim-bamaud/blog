

<h1><a href="<?php echo e(route('home.index')); ?>" class="text-gray-800 text-lg font-semibold mb-4">Developers Blog</a> </h1>
<?php /**PATH C:\laragon\www\blog\resources\views/components/application-logo.blade.php ENDPATH**/ ?>