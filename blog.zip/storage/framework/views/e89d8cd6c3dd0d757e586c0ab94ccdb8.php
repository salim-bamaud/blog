<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devs Blog</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100">
    <nav class="fixed top-0 left-0 right-0 z-50 bg-gray-800 p-4">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <a href="<?php echo e(route('home.index')); ?>" class="text-white text-lg font-semibold">Devs Blog</a>
            <div class="flex">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('filament.admin.auth.login')); ?>"
                        class="text-gray-200 hover:bg-gray-200 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Dashboard</a>

                    <form action="<?php echo e(route('filament.admin.auth.logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                            class="text-gray-200 hover:bg-gray-200 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('filament.admin.auth.login')); ?>"
                        class="text-gray-200 hover:bg-gray-200 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Login</a>
                    <a href="<?php echo e(route('filament.admin.auth.register')); ?>"
                        class="text-gray-200 hover:bg-gray-200 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>


    <footer class="bg-gray-800 text-white py-4 px-6 text-center mt-20">
        <p> &copy; <?php echo e(date('Y')); ?> Devs Blog. All rights reserved. </p>
    </footer>

</body>

</html>
<?php /**PATH C:\laragon\www\blog\resources\views/layouts/post.blade.php ENDPATH**/ ?>