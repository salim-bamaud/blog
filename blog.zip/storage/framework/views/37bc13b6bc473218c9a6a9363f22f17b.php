<?php $__env->startSection('content'); ?>
    <?php if(session()->has('success')): ?>
        <h3 class="bg-green-500 text-white rounded p-4 mt-20 m-4"> <?php echo e(session('success')); ?> </h3>
    <?php endif; ?>


    <div class="bg-white shadow-md rounded-md p-4 mt-20 m-10 flex justify-center text-center">
        <div class="flex flex-col items-center">
            <h2 class="text-xl font-semibold mb-2 mt-4"><?php echo e($post->title); ?></h2>
            <img src="
            <?php if($post->thumbnail === null): ?> <?php echo e(asset('/no-thumbnail-image.jpg')); ?>

            <?php else: ?>
            <?php echo e(asset('storage/' . $post->thumbnail)); ?> <?php endif; ?>"
                alt="Post Thumbnail" class="w-100 h-80 mt-10 mb-8 rounded">
            <p class="text-gray-600"><?php echo $post->content; ?></p>
            <p class="text-sm text-gray-400">
                <?php if(Auth::id() == $post->user_id): ?>
                    You
                <?php else: ?>
                    <?php echo e($post->user->name); ?>

                <?php endif; ?>
            </p>
            <p class="text-sm text-gray-400"><?php echo e($post->created_at->format('M d, Y')); ?></p>


            <div class="m-4">
                <ul class="flex justify-center">
                    <?php $__empty_1 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li
                            class="flex items-center justify-center bg-gray-500 text-white rounded-xl py-1 px-3 mr-2 text-xs">
                            <a href="/?tag=<?php echo e($tag); ?>"> <?php echo e($tag); ?> </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="w-full mt-10 p-4 justify-start">
                comments: <?php echo e(' ' . $post->comments->count()); ?>

                <hr>

                <!-- Comment Form -->
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('comments.store')); ?>" method="POST" class="mt-4">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500">error occured!</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <textarea name="content" class="w-full p-2 rounded-md border-gray-300" placeholder="Write a comment..." rows="3"></textarea>

                        <button type="submit"
                            class="mt-0 mb-4 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md">Submit</button>
                    </form>
                <?php else: ?>
                    <div class="m-4">
                        <a href="<?php echo e(route('filament.admin.auth.login')); ?>"
                            class="mb-4 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md">Log in
                            to comment </a>
                    </div>
                <?php endif; ?>
                <!-- Displaying comments -->
                <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($comment->parent_id == null): ?>
                        <div class="bg-gray-100 p-4 rounded-md mb-4">
                            <p class="text-sm text-gray-400">
                                <?php if(Auth::id() == $comment->user_id): ?>
                                    <?php echo e('You' . ' @' . $comment->created_at->format('M d, Y')); ?>

                                <?php else: ?>
                                    <?php echo e($comment->user->name . ' @ ' . $comment->created_at->format('M d, Y')); ?>

                                <?php endif; ?>
                            </p>
                            <p class="text-gray-600"><?php echo e($comment->content); ?></p>

                            <!-- Show replies -->
                            <?php if($comment->replies->count() > 0): ?>
                                <div class="mt-4 ml-4">
                                    <h4 class="text-sm font-medium">Replies:</h4>
                                    <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="bg-gray-200 p-2 rounded-md mt-2">
                                            <p class="text-sm text-gray-400">
                                                <?php if(Auth::id() == $reply->user_id): ?>
                                                    <?php echo e('You' . ' @' . $reply->created_at->format('M d, Y')); ?>

                                                <?php else: ?>
                                                    <?php echo e($reply->user->name . ' @ ' . $reply->created_at->format('M d, Y')); ?>

                                                <?php endif; ?>
                                            </p>
                                            <p class="text-gray-600"><?php echo e($reply->content); ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->guard()->check()): ?>
                                <!-- Reply field and button -->
                                <form action="<?php echo e(route('comments.store', $comment->id)); ?>" method="POST"
                                    class="mt-4 flex opacity-60">
                                    <?php echo csrf_field(); ?>
                                    <div class="mr-2 flex-grow">
                                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                        <input type="text" name="content" id="content" class="w-full rounded-md"
                                            placeholder="Write a reply">
                                    </div>
                                    <div>
                                        <button type="submit"
                                            class="bg-blue-500 text-white px-2 py-1 rounded-md text-sm">Reply</button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="bg-gray-100 p-4 rounded-md mb-4">
                        <p class="text-sm text-gray-400">
                            No comments.</p>
                    </div>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <!-- Add the report button -->
                    <button class="text-red-500" id="reportButton<?php echo e($post->id); ?>" data-toggle="modal"
                        data-target="#reportModal<?php echo e($post->id); ?>">Report</button>

                    <!-- Add the report modal -->
                    <div class="hidden" id="reportModal<?php echo e($post->id); ?>">
                        <form action="<?php echo e(route('post.report', $post->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                <input type="text" name="content" id="reason" class="form-control">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get the report button element
            var reportButton = document.getElementById('reportButton<?php echo e($post->id); ?>');

            // Get the report modal element
            var reportModal = document.getElementById('reportModal<?php echo e($post->id); ?>');

            // Add click event listener to the report button
            reportButton.addEventListener('click', function() {
                if (reportModal.style.display === 'block') {
                    // Hide the report modal
                    reportModal.classList.remove('show');
                    reportModal.style.display = 'none';
                    reportModal.setAttribute('aria-hidden', 'true');
                    document.body.classList.remove('modal-open');
                } else {
                    // Show the report modal
                    reportModal.classList.add('show');
                    reportModal.style.display = 'block';
                    reportModal.setAttribute('aria-hidden', 'false');
                    document.body.classList.add('modal-open');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>