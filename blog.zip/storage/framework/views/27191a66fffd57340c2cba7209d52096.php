<?php $__env->startSection('content'); ?>
    <div class="pt-16">
        <form action="/">
            <div class="relative border-2 border-gray-100 m-4 rounded-lg">
                <div class="absolute top-4 left-3">
                    <i class="fa fa-search text-gray-400 z-20 hover:text-gray-500"></i>
                </div>
                <input type="text" name="search"
                    class="h-14 w-full pl-10 pr-20 rounded-lg z-0 focus:shadow focus:outline-none" placeholder="Search ..." />
                <div class="absolute top-2 right-2">
                    <button type="submit"
                        class="h-10 w-20 text-white rounded-lg bg-gray-500 hover:bg-gray-800">Search</button>
                </div>
            </div>
        </form>
        <h1 class="text-3xl font-semibold text-center mt-10 mb-10">Welcome to the best Developers Blog</h1>

        <section class="max-w-3xl mx-auto">

            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white shadow-md rounded-md p-4 mb-4">
                    <a href="<?php echo e(route('home.show', $post->slug)); ?>">
                        <div class="flex">
                            <img src="<?php if($post->thumbnail === null): ?> <?php echo e(asset('/no-thumbnail-image.jpg')); ?>

            <?php else: ?>
            <?php echo e(asset('storage/' . $post->thumbnail)); ?> <?php endif; ?>"
                                alt="Post Thumbnail" class="w-16 h-16 mr-4 rounded">
                            <div>
                                <h2 class="text-xl font-semibold mb-2"><?php echo e($post->title); ?></h2>
                                <p class="text-gray-600">
                                    <?php echo Illuminate\Support\Str::limit(strip_tags($post->content), 200); ?>

                                </p>
                                <ul class="flex justify-center">
                                    <?php $__empty_2 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <li
                                            class="flex items-center justify-center bg-gray-800 text-white rounded-xl py-1 px-3 mr-2 text-xs">
                                            <a href="/?tag=<?php echo e($tag); ?>"> <?php echo e($tag); ?> </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <?php endif; ?>
                                </ul>

                                <div class="flex justify-between mt-4">
                                    <div class="flex items-center">
                                        <p class="text-sm text-gray-400">
                                            <?php if(Auth::id() == $post->user_id): ?>
                                                <b>You</b>
                                            <?php else: ?>
                                                <?php echo e($post->user->name); ?>

                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <p class="text-sm text-gray-400"><?php echo e($post->comments->count() . ' comments'); ?></p>

                                    <p class="text-sm text-gray-400"><?php echo e($post->created_at->format('M d, Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="bg-white shadow-md rounded-md p-4 mb-4">
                    <h2 class="text-xl font-semibold mb-2">There is no Posts until now </h2>
                    <p class="text-gray-600">login or register to make some posts.</p>
                </div>
            <?php endif; ?>
        </section>



        <div class="mt-4 flex justify-center">
            <?php echo e($posts->links()); ?>

        </div>



        <div class="flex justify-center mt-6">



            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('filament.admin.auth.login')); ?>"
                    class="bg-gray-800 hover:bg-gray-600 text-white py-2 px-4 rounded-md mr-4">Create
                    New Post </a>
            <?php else: ?>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/posts/index.blade.php ENDPATH**/ ?>